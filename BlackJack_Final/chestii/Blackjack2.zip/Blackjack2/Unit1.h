//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ExtCtrls.hpp>
#include "Deck.h"
#include "Card.h"
#include <Vcl.Imaging.jpeg.hpp>

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TPanel *PanelHit;
	TImage *Background;
	TImage *Dcarte1;
	TImage *Dcarte2;
	TImage *Dcarte3;
	TImage *Dcarte4;
	TImage *Dcarte5;
	TImage *Pcarte1;
	TImage *Pcarte2;
	TImage *Pcarte3;
	TImage *Pcarte4;
	TImage *Pcarte5;
	TPanel *PanelStand;
	TPanel *PanelStart;
	TPanel *PanelReset;
	void __fastcall PanelHitClick(TObject *Sender);
	void __fastcall PanelStandClick(TObject *Sender);
	void __fastcall PanelStartClick(TObject *Sender);
private:	// User declarations
	Deck deck;
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
	void displayCard;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
