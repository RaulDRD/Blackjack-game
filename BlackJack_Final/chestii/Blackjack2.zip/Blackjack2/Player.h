#pragma once
#include <vector>
#include "Deck.h"
#include "Card.h"
#include <iostream>

class Player
{
	private:
		vector <Card> playerHand;

};

